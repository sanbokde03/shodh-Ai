import argparse
import json
import sys

from .contracts import load_json
from .engine import review
from .model import Config, FakeClient, OllamaClient


def main():
    parser = argparse.ArgumentParser(description="Review a policy/spec/workflow/code JSON bundle")
    parser.add_argument("bundle")
    parser.add_argument("--output", help="Write JSON to this file; default stdout")
    parser.add_argument("--fake-mode", default="ok", help="Offline test response: ok,timeout,malformed,truncated,invented,conflict,omit,ambiguous; comma-separated retry sequence")
    parser.add_argument("--ollama-model", help="Use a locally installed Ollama model instead of synthetic responses")
    args = parser.parse_args()
    try:
        bundle = load_json(args.bundle)
        client = OllamaClient() if args.ollama_model else FakeClient(args.fake_mode)
        report = review(bundle, client, Config(model=args.ollama_model or "offline-fake"))
    except (ValueError, OSError, RecursionError) as exc:
        report = {"status": "INCOMPLETE", "summary": f"Input could not be read: {type(exc).__name__}: {exc}",
                  "findings": [], "coverage": {"unreviewed": [{"scope": "entire_input", "reason": str(exc)}]},
                  "check_results": [{"check": "input_read", "status": "INCOMPLETE"}]}
    text = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        with open(args.output, "w") as stream:
            stream.write(text)
    else:
        print(text, end="")
    return {"PASS": 0, "CHANGES_REQUIRED": 1, "INCOMPLETE": 2}[report["status"]]


if __name__ == "__main__":
    sys.exit(main())
