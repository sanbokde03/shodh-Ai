import copy
import json
import unittest

from reviewer.contracts import ROOT, Unsupported, load_json
from reviewer.engine import review
from reviewer.language import Code, evaluate, normalize, parse_source, representatives
from reviewer.model import Config, FakeClient


def fixture(name="valid_base"):
    return load_json(ROOT / "evaluation/inputs" / f"{name}.json")


class ReviewerTests(unittest.TestCase):
    def test_valid_base(self):
        r = review(fixture())
        self.assertEqual(r["status"], "PASS", r["coverage"])
        self.assertGreater(r["coverage"]["representative_tickets"], 1)

    def test_exhaustive_integer_partition_against_direct_oracle(self):
        fields = {"wait": {"type": "number", "unit": "seconds"}}
        expr, _ = parse_source("IF wait >= 0.5 minutes THEN escalation", fields)
        tickets, _ = representatives([expr], fields)
        observed = {evaluate(expr, t) for t in tickets}
        self.assertEqual(observed, {False, True})
        for n in range(-100, 101):
            self.assertEqual(evaluate(expr, {"wait": n}), n >= 30)

    def test_equivalent_nested_boolean_formulation(self):
        r = review(fixture("valid_unusual_units"))
        self.assertEqual(r["status"], "PASS", r)

    def test_precedence_has_joint_counterexample(self):
        r = review(fixture("defect_precedence"))
        examples = [f["counterexample"] for f in r["findings"] if f["artifact"] == "workflow"]
        self.assertTrue(any(e["expected_route"] == "manual" and e["actual_route"] == "priority" and e["ticket"]["urgent"] is True for e in examples))

    def test_omitted_rule_still_has_source_reference(self):
        r = review(fixture("defect_omission"))
        self.assertTrue(any(f["rule_ref"] == "R3" and f["artifact"] == "specification" and f["evidence"][0]["artifact"] == "source" for f in r["findings"]))

    def test_approved_and_proposed_changes(self):
        for name in ("valid_approved", "valid_unapproved_ignored"):
            self.assertEqual(review(fixture(name))["status"], "PASS")
        self.assertEqual(review(fixture("defect_stale_revision"))["status"], "CHANGES_REQUIRED")

    def test_approval_conflict_never_picks_one(self):
        r = review(fixture("incomplete_approval_conflict"))
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertIn("Conflicting approvals", r["coverage"]["unreviewed"][0]["reason"])

    def test_model_failures_never_pass(self):
        for mode in ("timeout", "malformed", "truncated", "invented", "omit", "oversized"):
            with self.subTest(mode=mode):
                r = review(fixture(), FakeClient(mode))
                self.assertEqual(r["status"], "INCOMPLETE")
                self.assertEqual(r["resources"]["model_calls"], 2)

    def test_retry_recovers_with_provenance(self):
        r = review(fixture(), FakeClient("timeout,ok"))
        self.assertEqual(r["status"], "PASS")
        self.assertEqual(r["resources"]["model_retries"], 1)
        self.assertEqual(len(r["model"]["request_sha256"]), 64)

    def test_model_cannot_overrule_a_counterexample(self):
        r = review(fixture("defect_boundary"), FakeClient("conflict"))
        self.assertEqual(r["status"], "CHANGES_REQUIRED")
        self.assertTrue(any(u["scope"] == "model_review" for u in r["coverage"]["unreviewed"]))

    def test_missing_branch_has_concrete_witness(self):
        b = fixture()
        b["workflow"]["nodes"][2]["true"] = "nonexistent"
        r = review(b)
        self.assertEqual(r["status"], "CHANGES_REQUIRED")
        self.assertTrue(any(f.get("counterexample", {}).get("actual_route") == "ERROR:missing_branch" for f in r["findings"]))

    def test_unknown_python_is_not_executed(self):
        b = fixture()
        b["snippets"][0]["code"] = 'import os\nos.remove("important_file")'
        r = review(b)
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertTrue(any(u["scope"] == "code_inspection" for u in r["coverage"]["unreviewed"]))

    def test_syntax_error_is_distinct_from_execution(self):
        b = fixture()
        b["snippets"][0]["code"] = "def route(ticket)\n    return 'normal'"
        r = review(b)
        self.assertEqual(r["status"], "CHANGES_REQUIRED")
        self.assertEqual(r["findings"][0]["kind"], "syntax_error")

    def test_oversized_partition_abstains(self):
        r = review(fixture(), max_tickets=1)
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertIn("no sampling", r["coverage"]["unreviewed"][0]["reason"])

    def test_model_request_is_not_truncated(self):
        r = review(fixture(), config=Config(max_request_bytes=10))
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertEqual(r["resources"]["model_calls"], 0)

    def test_contract_rejects_bad_types_and_unknown_properties(self):
        for change in (lambda b: b.update(revision=True), lambda b: b.update(secret="no")):
            b = fixture()
            change(b)
            self.assertEqual(review(b)["status"], "INCOMPLETE")

    def test_no_stale_passing_report(self):
        b = fixture()
        first = review(b)
        b["workflow"]["nodes"][2]["true"] = "out_normal"
        second = review(b)
        self.assertEqual(second["status"], "CHANGES_REQUIRED")
        self.assertNotEqual(first["provenance"]["bundle_sha256"], second["provenance"]["bundle_sha256"])


if __name__ == "__main__":
    unittest.main()
