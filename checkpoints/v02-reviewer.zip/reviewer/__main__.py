import argparse
import json
import sys

from .contracts import load_json
from .engine import review
from .model import Config, FakeClient, OllamaClient


def main():
    parser = argparse.ArgumentParser(description="Review a policy/spec/workflow/code JSON bundle")
    parser.add_argument("bundle")
    parser.add_argument("--output", help="Write JSON to this file; default stdout")
    parser.add_argument("--tickets", help="Optional JSON array of tickets to explain alongside exhaustive review")
    parser.add_argument("--fake-mode", default="ok", help="Offline test response: ok,timeout,malformed,truncated,invented,conflict,omit,ambiguous; comma-separated retry sequence")
    parser.add_argument("--ollama-model", help="Use a locally installed Ollama model instead of synthetic responses")
    parser.add_argument("--no-thinking", action="store_true", help="Disable thinking for a local model that supports this setting")
    parser.add_argument("--model-timeout", type=int, default=30, help="Live socket timeout in seconds, 1-120")
    args = parser.parse_args()
    try:
        bundle = load_json(args.bundle)
        client = OllamaClient() if args.ollama_model else FakeClient(args.fake_mode)
        tickets = load_json(args.tickets) if args.tickets else []
        config = Config(model=args.ollama_model or "offline-fake", timeout_seconds=args.model_timeout if args.ollama_model else 5,
                        thinking=False if args.no_thinking else None)
        report = review(bundle, client, config, provided_tickets=tickets)
    except (ValueError, OSError, RecursionError) as exc:
        report = {"status": "INCOMPLETE", "summary": f"Input could not be read: {type(exc).__name__}: {exc}",
                  "findings": [], "coverage": {"unreviewed": [{"scope": "entire_input", "reason": str(exc)}]},
                  "check_results": [{"check": "input_read", "status": "INCOMPLETE"}]}
    text = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        with open(args.output, "w") as stream:
            stream.write(text)
    else:
        print(text, end="")
    return {"PASS": 0, "CHANGES_REQUIRED": 1, "INCOMPLETE": 2}[report["status"]]


if __name__ == "__main__":
    sys.exit(main())
