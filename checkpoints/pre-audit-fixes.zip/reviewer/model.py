"""Bounded model calls and evidence validation, separate from deterministic truth."""

import hashlib
import json
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from typing import Protocol

from .contracts import ROOT, Unsupported, validate

PROMPT = (ROOT / "reviewer/prompt.txt").read_text()
MODEL_SCHEMA = json.loads((ROOT / "schemas/model-report.schema.json").read_text())
MAX_RESPONSE = 65536


@dataclass(frozen=True)
class Config:
    model: str = "offline-fake"
    temperature: int = 0
    timeout_seconds: int = 5
    max_attempts: int = 2
    max_output_tokens: int = 2048
    max_request_bytes: int = 200000


class ModelClient(Protocol):
    provenance: str

    def complete(self, request: dict, config: Config) -> str: ...


class FakeClient:
    provenance = "synthetic-fake; not evidence of real-model performance"

    def __init__(self, modes="ok"):
        self.modes = modes.split(",")
        self.calls = 0

    def complete(self, request, config):
        mode = self.modes[min(self.calls, len(self.modes) - 1)]
        self.calls += 1
        if mode == "timeout":
            raise TimeoutError("Injected fake-client timeout; no real waiting")
        if mode in ("malformed", "truncated"):
            return "not JSON" if mode == "malformed" else '{"coverage": ['
        if mode == "oversized":
            return " " * (MAX_RESPONSE + 1)
        claims = []
        for rule in request["effective_rules"]:
            evidence = rule["evidence"][-1]
            claims.append({"rule_ref": rule["id"], "judgment": "no_additional_issue",
                           **evidence, "explanation": "Synthetic response for contract tests only."})
        response = {"coverage": [r["id"] for r in request["effective_rules"]], "claims": claims}
        if mode == "invented" and claims:
            claims[0]["location"] = "invented/location"
        elif mode == "conflict":
            for claim in claims:
                claim["judgment"] = "equivalent"
        elif mode == "omit":
            response["coverage"] = []
        elif mode == "ambiguous" and claims:
            claims[0]["judgment"] = "ambiguous"
        elif mode != "ok":
            if mode not in ("invented", "conflict", "omit", "ambiguous"):
                raise Unsupported(f"Unknown fake mode {mode}")
        return json.dumps(response)


class OllamaClient:
    provenance = "live-local-ollama"

    def complete(self, request, config):
        payload = {"model": config.model, "stream": False, "format": MODEL_SCHEMA,
                   "messages": [{"role": "system", "content": PROMPT},
                                {"role": "user", "content": json.dumps(request)}],
                   "options": {"temperature": config.temperature, "num_predict": config.max_output_tokens}}
        req = urllib.request.Request("http://127.0.0.1:11434/api/chat", data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=config.timeout_seconds) as response:
            raw = response.read(MAX_RESPONSE + 1)
        if len(raw) > MAX_RESPONSE:
            raise Unsupported("Model transport response exceeds byte limit")
        body = json.loads(raw)
        if type(body) is not dict or body.get("done") is not True or body.get("done_reason") not in (None, "stop"):
            raise Unsupported("Model response is incomplete")
        if type(body.get("message")) is not dict or type(body["message"].get("content")) is not str:
            raise Unsupported("Model transport has no message content")
        self.last_metadata = {k: body[k] for k in ("model", "created_at", "done_reason", "prompt_eval_count", "eval_count") if k in body}
        return body["message"]["content"]


def review_model(client, config, rules, evidence, findings, fields):
    request = {"effective_rules": rules, "evidence_inventory": evidence,
               "deterministic_findings": findings, "field_contract": fields}
    encoded = json.dumps({"system": PROMPT, "request": request}, sort_keys=True).encode()
    info = {"client": client.provenance, "configuration": asdict(config),
            "prompt_sha256": hashlib.sha256(PROMPT.encode()).hexdigest(),
            "response_schema_sha256": hashlib.sha256(json.dumps(MODEL_SCHEMA, sort_keys=True).encode()).hexdigest(),
            "request_sha256": hashlib.sha256(encoded).hexdigest(), "attempts": [], "calls": 0, "retries": 0}
    if not (1 <= config.max_attempts <= 3 and 1 <= config.timeout_seconds <= 30
            and 1 <= config.max_output_tokens <= 4096 and 1 <= config.max_request_bytes <= 500000):
        return info, ["Invalid model resource limits"], []
    if len(encoded) > config.max_request_bytes:
        return info, ["Model input exceeds byte limit; no input was truncated or sent"], []
    expected = {r["id"] for r in rules}
    source_anchors = {r["id"]: {(e["artifact"], e["version"], e["location"]) for e in r["evidence"]}
                      for r in rules}
    allowed = {(e["artifact"], e["version"], e["location"]): e["quote"] for e in evidence}
    for attempt in range(config.max_attempts):
        start = time.perf_counter()
        record = {"attempt": attempt + 1}
        info["calls"] += 1
        info["retries"] = attempt
        try:
            raw = client.complete(request, config)
            if hasattr(client, "last_metadata"):
                record["transport"] = client.last_metadata
            if type(raw) is not str or len(raw.encode()) > MAX_RESPONSE:
                raise Unsupported("Model output exceeds byte limit or is not text")
            record["response_sha256"] = hashlib.sha256(raw.encode()).hexdigest()
            record["response"] = raw
            result = json.loads(raw)
            validate(result, MODEL_SCHEMA)
            if set(result["coverage"]) != expected or len(result["coverage"]) != len(expected):
                raise Unsupported("Model coverage does not exactly match effective requirements")
            if {c["rule_ref"] for c in result["claims"]} != expected:
                raise Unsupported("Model claims omit or invent rule references")
            ambiguities = []
            judgments = {}
            for claim in result["claims"]:
                key = (claim["artifact"], claim["version"], claim["location"])
                if key not in allowed or claim["quote"] not in allowed[key]:
                    raise Unsupported("Model cited invented evidence or an invalid quote")
                if claim["artifact"] in ("source", "approvals") and key not in source_anchors[claim["rule_ref"]]:
                    raise Unsupported("Model attributed source evidence to the wrong rule")
                prior = judgments.setdefault(claim["rule_ref"], claim["judgment"])
                if prior != claim["judgment"]:
                    raise Unsupported("Model made conflicting claims for one rule")
                if claim["judgment"] == "equivalent" and any(
                        f.get("rule_ref") == claim["rule_ref"] and f["severity"] == "blocker" for f in findings):
                    raise Unsupported("Model equivalence claim conflicts with deterministic evidence")
                if claim["judgment"] == "ambiguous":
                    ambiguities.append(claim)
            record["result"] = "validated"
            record["seconds"] = time.perf_counter() - start
            info["attempts"].append(record)
            return info, [], ambiguities
        except (ValueError, TimeoutError, OSError, KeyError, TypeError) as exc:
            record.update(result="rejected", error=f"{type(exc).__name__}: {exc}", seconds=time.perf_counter() - start)
            info["attempts"].append(record)
    return info, [info["attempts"][-1]["error"]], []
