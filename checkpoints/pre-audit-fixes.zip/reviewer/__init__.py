"""Offline, evidence-backed review of bounded ticket-routing policies."""

__version__ = "0.1.0"
